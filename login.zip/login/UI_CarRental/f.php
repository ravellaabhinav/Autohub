<?php
$name = $_POST['name'];
$EMail = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

$conn = new mysqli('localhost','root','','test_db');
if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
}else{
    $stmt = $conn->prepare("insert into regfeedback(name, email, subject, message)
        values(?,?,?,?)");
    $stmt->bind_param("ssss",$Name,$EMail,$Subject,$Feedback);
    $stmt->execute();
    header("Location:contact.php");
    $stmt->close();
    $conn->close();

}
?>
