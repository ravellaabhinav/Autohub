<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>AutoHub</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
    <link rel="stylesheet" href="assets/css/owl.css">

  </head>

  <body>
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php"><h2>AutoHub <em>Online</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item active">
                <a class="nav-link" href="index.php">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="products.php">Our Products</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.php">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="contact.php">Contact Us</a>
              </li>
                <li class="nav-item">
                    <a class="nav-link" href="info/info.html">Personal Info</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="signout.php"><abbr title="Signout"><i class="fa fa-power-off" style="font-size:26px"></i></abbr>    </a>
              <li class="nav-item">

              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <div class="banner header-text">
      <div class="owl-banner owl-carousel">
        <div class="banner-item-01">
          <div class="text-content">
            <h4>We have more than a thousand cars for you to choose.</h4>
            <h2>FIND THE RIGHT CAR FOR YOU.</h2>
          </div>
        </div>
        <div class="banner-item-02">
          <div class="text-content">
            <h4>Pick Me</h4>
            <h2>Move Beyond Your Choice</h2>
          </div>
        </div>
        <div class="banner-item-03">
          <div class="text-content">
            <h4>Hurry Up</h4>
            <h2>Upto 25% off on first booking</h2>
          </div>
        </div>
      </div>
    </div>


    <div class="latest-products">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Best Grabs</h2>
              <a href="products.php">view all cars <i class="fa fa-angle-right"></i></a>
            </div>
          </div>
          <div class="col-md-4">
            <div class="product-item">
              <a href="#"><img src="assets/images/1.jpg" alt=""></a>
              <div class="down-content">
                <a href="#"><h4>Maruti DZire</h4></a>
                <h6>Rs9/KM</h6>
                <p>Maruti Suzuki Dzire [2020] is a Five seater Compact Sedan.It is available in 2 variants, 1 engine option and 1 transmission.</p>
                  <br> <p>
                      <i class="fa fa-user"></i> 5 &nbsp;&nbsp;
                      <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;
                      <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;
                      <i class="fa fa-cog"></i> A
                  </p>
                  <center><a href="book/book.html" class="filled-button" >Book Now</a><br></center>
                  <br>
                <ul class="stars">
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                </ul>
                <span>Reviews (24)</span>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="product-item">
              <a href="#"><img src="assets/images/2.jpg" alt=""></a>
              <div class="down-content">
                <a href="#"><h4>Chevrolet Spark</h4></a>
                <h6>Rs8/KM</h6>
                  <p>Spark. Its small size and easy maneuverability make it well-suited to city driving, though it can feel underpowered and unrefined at higher speeds.</p>
                  <p>
                      <i class="fa fa-user"></i> 5 &nbsp;&nbsp;
                      <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;
                      <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;
                      <i class="fa fa-cog"></i> A
                  </p>
                  <center><a href="book/book.html" class="filled-button" >Book Now</a></center><br>
                <ul class="stars">
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                </ul>
                <span>Reviews (21)</span>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="product-item">
              <a href="#"><img src="assets/images/3.jpg" alt=""></a>
              <div class="down-content">
                <a href="#"><h4>Toyota Yaris</h4></a>
                <h6>Rs9/KM</h6>
                <p>The Yaris’ Hill-start assist control feature lets you start up your car when on a slope without fear of sliding back.</p>
                  <br> <p>
                      <i class="fa fa-user"></i> 5 &nbsp;&nbsp;
                      <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;
                      <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;
                      <i class="fa fa-cog"></i> A
                  </p>
                  <center><a href="book/book.html" class="filled-button" >Book Now</a></center><br>
                <ul class="stars">
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                </ul>
                <span>Reviews (36)</span>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="product-item">
              <a href="#"><img src="assets/images/images.jpg" alt=""></a>
              <div class="down-content">
                <a href="#"><h4>Nissan Altima</h4></a>
                <h6>Rs10/KM</h6>
                <p>Nissan Altima is the most alluring or exciting family sedan, but it's competent and available with some unconventional options.</p>
                  <p>
                      <i class="fa fa-user"></i> 5 &nbsp;&nbsp;
                      <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;
                      <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;
                      <i class="fa fa-cog"></i> A
                  </p>
                  <center><a href="#" class="filled-button" >Book Now</a></center><br>
                <ul class="stars">
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                </ul>
                <span>Reviews (48)</span>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="product-item">
              <a href="#"><img src="assets/images/5.jpg" alt=""></a>
              <div class="down-content">
                <a href="#"><h4>Suzuki Ertiga</h4></a>
                <h6>Rs11/KM</h6>
                <p>The Ertiga flaunts a bold personality that is carved into every crease, corner and contour of its design.</p>
                  <br><p>
                      <i class="fa fa-user"></i> 5 &nbsp;&nbsp;
                      <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;
                      <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;
                      <i class="fa fa-cog"></i> A
                  </p>
                  <center><a href="#" class="filled-button" >Book Now</a></center><br>
                <ul class="stars">
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                </ul>
                <span>Reviews (16)</span>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="product-item">
              <a href="#"><img src="assets/images/6.jpg" alt=""></a>
              <div class="down-content">
                <a href="#"><h4>Toyota Innova</h4></a>
                <h6>Rs12/KM</h6>
                <p>The GD Diesel Engine has improved fuel economy performance while torque in the medium speed ranges have been considerably increased.</p>
                  <p>
                      <i class="fa fa-user"></i> 5 &nbsp;&nbsp;
                      <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;
                      <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;
                      <i class="fa fa-cog"></i> A
                  </p>
                  <center><a href="#" class="filled-button" >Book Now</a></center><br>
                <ul class="stars">
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                  <li><i class="fa fa-star"></i></li>
                </ul>
                <span>Reviews (32)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="best-features">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>About AutoHub</h2>
            </div>
          </div>
          <div class="col-md-6">
            <div class="left-content">
              <h4>What makes our car rental websites unique?</h4>
              <p>All our car rental websites and booking solutions are different according to the requirement of individual car rental companies, agencies and taxi & tour operators.</p>
              <ul class="featured-list">
                <li><a href="#">Bespoke car rental websites </a></li>
                <li><a href="#"> Integration of Tailor made online booking engine</a></li>
                <li><a href="#">Lucrative display of rental cars with online price</a></li>
                <li><a href="#">User centric design to manage user attention</a></li>
                <li><a href="#">Clear site structure</a></li>
              </ul>
              <a href="about.php" class="filled-button">Read More</a>
            </div>
          </div>
          <div class="col-md-6">
            <div class="right-image">
              <img src="assets/images/blog_img2.jpg" alt="">
            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="call-to-action">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="inner-content">
              <div class="row">
                <div class="col-md-8">
                  <h4>Safety Simplified <em>Customer Friendly</em> Cars</h4>
                  <p>Automatic calculated rate chart at every booking steps</p>
                </div>
                <div class="col-md-4">
                  <a href="products.php" class="filled-button">Book Now</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="inner-content">
              <p>Copyright &copy; 2020 - All Rights Reserved. <a rel="nofollow noopener" href="contact.php" target="_blank">AutoHub</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>



    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>



    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/accordions.js"></script>


    <script language = "text/Javascript">
      cleared[0] = cleared[1] = cleared[2] = 0;
      function clearField(t){
      if(! cleared[t.id]){
          cleared[t.id] = 1;
          t.value='';
          t.style.color='#fff';
          }
      }
    </script>


  </body>

</html>
