<?php
$From = $_POST['From'];
$To = $_POST['To'];
$Type = $_POST['Type'];
$Seating_Capacity = $_POST['Seating_Capacity'];
$Adults = $_POST['Adults'];
$Children = $_POST['Children'];
$Name = $_POST['Name'];
$EMail = $_POST['EMail'];
$Special_Requirements = $_POST['Special_Requirements'];

$conn = new mysqli('localhost','root','','test_db');
if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
}

$qry="INSERT INTO book(From, To,Type,Seating_Capacity,Adults,Children,Name,Email,Phone,Special_Requirements)
VALUES ('$From', '$To', '$Type', '$Seating_Capacity', '$Adults', '$Children','$Name','$Email','$Phone','$Special_Requirements')";

if ($conn->query($qry) === TRUE) {
   echo " successfully entered";
} else {
  echo "Error: " . $qry . "<br>" . $conn->error;
}

?>
