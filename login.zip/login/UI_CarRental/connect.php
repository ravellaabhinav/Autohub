<?php
    $Name = $_POST['Name'];
    $EMail = $_POST['EMail'];
    $Password = $_POST['Password'];

    $conn = new mysqli('localhost','root','','autohub');
    if($conn->connect_error){
        die('Connection Failed : '.$conn->connect_error);
    }else{
        $stmt = $conn->prepare("insert into signup(Name, EMail, Password)
        values(?,?,?)");
        $stmt->bind_param("sss",$Name,$EMail,$Password);
        $stmt->execute();
        header("Location:index.php");
        $stmt->close();
        $conn->close();

    }
?>


