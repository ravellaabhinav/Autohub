<?php

//initialising the session
session_start();
//unsetting all the session variables
$_SESSION = array();
//destroying the session
session_destroy();

header("Location: ../../Autohub/index.html");
clearstatcache();
exit;
/**
 * This last line basically used to destroy the session and logout of the webapp and then redirect to the main page
 * and then encourage user to login again
 */

?>
